<?php 

class Smartwave_Revolutionslider_Block_Revolutionslider extends Mage_Core_Block_Template
{
    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }
}

?>