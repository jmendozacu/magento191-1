<?php

class Smartwave_Legenda_Model_System_Config_Source_Setting_Category_Maincatpos
{
    public function toOptionArray()
    {
        return array(
            array('value' => 'right', 'label' => 'right'),
            array('value' => 'left', 'label' => 'left')
        );
    }
}