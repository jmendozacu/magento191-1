<?php

class Smartwave_Zoom_Block_Product_View_Media extends Mage_Catalog_Block_Product_View_Media
{
}
