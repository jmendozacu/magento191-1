<?php
class Smartwave_SharingTool_Model_Source_Menuversions
{

    public function toOptionArray()
    {
        return array(
            array('value' => '300', 'label'=>'New'),
            array('value' => '250', 'label'=>'Classic'),      
        );
    }

}
