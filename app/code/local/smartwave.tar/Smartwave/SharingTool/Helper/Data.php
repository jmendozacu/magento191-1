<?php

class Smartwave_SharingTool_Helper_Data extends Mage_Core_Helper_Abstract
{
    
}